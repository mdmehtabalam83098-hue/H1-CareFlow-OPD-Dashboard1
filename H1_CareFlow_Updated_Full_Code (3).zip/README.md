# H1 CareFlow — Updated Full Code (Student Demo)

## Files
- `index.html`: complete responsive frontend (HTML, CSS and JavaScript)
- `backend/main.py`: FastAPI demo backend
- `backend/requirements.txt`: Python dependencies
- `.gitignore`: ignores local environment and secrets

## Publish frontend on GitHub Pages
1. Upload `index.html` directly into your repository root, not inside a folder.
2. Open repository **Settings → Pages**.
3. Select **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
4. Wait for deployment and open your GitHub Pages URL.

The frontend works in demo mode without a backend. Records are saved in the current browser only.

## Run backend locally on Windows
Open terminal inside `backend`:
```powershell
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
$env:FRONTEND_ORIGIN="http://127.0.0.1:5500"
uvicorn main:app --reload
```
Then open `http://127.0.0.1:8000/`, `/health`, or `/docs`.

In the website's **Connect your backend** section, enter the backend base URL and click **Save API URL**, then **Test connection**. For GitHub Pages, `FRONTEND_ORIGIN` must be your site origin such as `https://YOUR-USERNAME.github.io` (no repository path).

## Limitations / safety
- This is not real AI and does not diagnose.
- Warning-sign detection is a simple demo rule, not a validated clinical protocol.
- Backend records are stored in RAM and disappear when it restarts.
- No real doctor notification, SMS, email, authentication, or persistent database is configured.
- Use fictional data only. Do not expose this demo API publicly with real patient information.
- Before real-world use, add authentication/authorization, secure database persistence, audit logging, encryption, retention rules, monitoring, validated clinical workflows and clinical/privacy review. Never place database secrets in frontend code or a public repository.
