import os
from datetime import datetime, timezone
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, ConfigDict

app = FastAPI(title="H1 CareFlow API", version="2.0.0",
              description="Student demo API for OPD registration and triage-support workflow.")

origins = [x.strip() for x in os.getenv("FRONTEND_ORIGIN", "http://127.0.0.1:5500").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False,
                   allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["Content-Type", "Authorization"])

class PatientIn(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)
    patient_label: str = Field(min_length=1, max_length=80)
    age: int = Field(ge=0, le=120)
    symptoms: str = Field(min_length=1, max_length=1500)
    department: str = Field(min_length=1, max_length=80)
    location: str = Field(default="Main OPD — Ground floor (demo)", max_length=120)
    warning_signs: List[str] = Field(default_factory=list, max_length=10)
    token: Optional[str] = Field(default=None, max_length=20)

patients = []  # In-memory demo only; restart clears data.
TERMS = {
 "Severe breathing difficulty": ["severe breathing difficulty", "can't breathe", "cannot breathe", "difficulty breathing", "shortness of breath"],
 "Chest pain or pressure": ["chest pain", "chest pressure", "pressure in chest"],
 "Unconsciousness or new confusion": ["unconscious", "passed out", "new confusion", "not responding"],
 "Severe bleeding": ["severe bleeding", "heavy bleeding", "bleeding heavily"],
 "Sudden weakness or trouble speaking": ["sudden weakness", "trouble speaking", "difficulty speaking", "face drooping"],
 "Seizure or rapid worsening": ["seizure", "rapid worsening", "getting worse quickly"],
}
def find_warnings(p):
    found = list(dict.fromkeys(p.warning_signs))
    text = p.symptoms.lower()
    for label, phrases in TERMS.items():
        if any(term in text for term in phrases) and label not in found:
            found.append(label)
    return found

@app.get("/")
def root():
    return {"project": "H1 CareFlow", "version": "2.0.0", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "ok", "database_connected": False, "ai_used": False, "notification_service_configured": False}

@app.get("/departments")
def departments():
    return [
      {"name":"General Medicine","location":"Main OPD — Ground floor (demo)"},
      {"name":"Cardiology","location":"First floor (demo)"},
      {"name":"Orthopedics","location":"First floor (demo)"},
      {"name":"Pediatrics","location":"Second floor (demo)"},
      {"name":"Dermatology","location":"Second floor (demo)"},
      {"name":"ENT","location":"Ground floor (demo)"}
    ]

@app.post("/patients", status_code=201)
def create_patient(p: PatientIn):
    warnings = find_warnings(p)
    token = p.token or f"HF-{len(patients)+1:03d}"
    record = {
      "id": len(patients)+1, "token": token, "patient_label": p.patient_label, "age": p.age,
      "symptoms": p.symptoms, "department": p.department, "location": p.location,
      "warning_signs": warnings, "priority": "URGENT_STAFF_REVIEW" if warnings else "UNASSESSED",
      "created_at": datetime.now(timezone.utc).isoformat()
    }
    patients.append(record)
    return {"patient": record, "ai_used": False, "notification_sent": False,
            "message": "Saved in backend memory only. No doctor notification was sent."}

@app.get("/patients")
def list_patients():
    # Demo-only endpoint. Do not expose publicly with real patient information.
    return {"patients": patients, "count": len(patients), "storage": "in-memory demo"}

@app.get("/queue")
def queue():
    return {"queue": [{"token": p["token"], "department": p["department"], "priority": p["priority"]} for p in patients]}

@app.get("/alerts")
def alerts():
    return {"alerts": [p for p in patients if p["warning_signs"]], "notification_sent": False}

@app.delete("/demo-data")
def clear_demo_data(confirm: bool = False):
    if not confirm:
        raise HTTPException(status_code=400, detail="Pass ?confirm=true to clear demo records.")
    patients.clear()
    return {"cleared": True}
